<?php
session_start();
require_once('inc/connect.php');
include('templates/header.php');
include('templates/nav.php');

$sql = "SELECT * FROM book";
$res = mysqli_query($connection, $sql);
?>

		<br>

		<div class="formContain center grid">

			<div class="formImgLog">
				<!-- <img src="Images\regImage" width="auto" height="100%"> -->
			</div>

			<div class = "center formContainer2">

				<h1 class="formTitle textCenter">Log-In</h1>

				<div class = "center">

					<form action="file1.php" method="POST" class="regForm">
						<h3>Enter Email</h3>
						<input type="text" name="Email">
						<h3>Enter Password</h3>
						<input type="password" name="Password">

						<div class="">
							<p>Dont have an Account? <a href="registration.php">Register Here!</a></p>
						</div>

						<input type="submit" name="submit" class="formBtn" value="Log In">
						</form>

				</div>



			</div>

		</div>

		<?php

		$Email = isset($_POST['Email']) ? $_POST['Email'] : '';
		$Password = isset($_POST['Password']) ? $_POST['Password'] : '';

		$sql = mysqli_connect("localhost", "root", "student", "Group_12_db");
		if (mysqli_connect_errno()) {
			printf("connect failed", mysqli_connect_error());
			exit();
		}
		$email = "SELECT Email,Password FROM customer_management";
		$res = mysqli_query($sql, $email);

		if ($res) {
			while ($newArray = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
				$EMAIL_C = $newArray['Email'];
				$PASSWORD_C = $newArray['Password'];
				if ($Email === $EMAIL_C && $Password === $PASSWORD_C) {
					echo "successful";

				}
			}
		}

		?>



	</body>
</html>
